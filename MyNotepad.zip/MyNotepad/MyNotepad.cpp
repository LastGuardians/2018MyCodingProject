#include <iostream>
#include <fstream>
using namespace std;

int main(int argc, char* argv[])
{
	ofstream textFile(argv[1]);

	if (true == textFile.is_open())
	{
		for (int i = 2; i < argc; ++i)
		{
			textFile << argv[i] << " ";
		}
	}
}